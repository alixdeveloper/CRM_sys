from django.apps import AppConfig


class TelegramBotConfig(AppConfig):
    name = 'telegram_bot'
